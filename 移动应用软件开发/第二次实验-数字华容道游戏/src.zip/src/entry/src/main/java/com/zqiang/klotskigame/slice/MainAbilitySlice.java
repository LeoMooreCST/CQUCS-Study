
package com.zqiang.klotskigame.slice;

import com.zqiang.klotskigame.ResourceTable;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.agp.components.*;

public class MainAbilitySlice extends AbilitySlice {
    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_ability_main);

        Button quickStart = findComponentById(ResourceTable.Id_quikstart_btn);
        Button modelSelect = findComponentById(ResourceTable.Id_modeselect_btn);
        Button history = findComponentById(ResourceTable.Id_history_btn);
        Button setting = findComponentById(ResourceTable.Id_setting_btn);
        //快速游戏
        quickStart.setClickedListener(component -> {
            present(new QuikStartAbilitySlice(),new Intent());
        });
        //模式选择
        modelSelect.setClickedListener(component -> {
            present(new ModeStartAbilitySlice(),new Intent());
        });
        //历史记录
        history.setClickedListener(component -> {
            present(new HistorySlice(),new Intent());
        });
        //游戏设置
        setting.setClickedListener(component -> {
            present(new SettingSlice(),new Intent());
        });
    }

    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }
}
