package com.zqiang.klotskigame.controller;

import com.zqiang.klotskigame.ResourceTable;
import ohos.agp.components.*;
import ohos.app.Context;

import java.util.List;

public class HistoryListProvider extends BaseItemProvider {
    List<String> historyList;
    Context context;

    public HistoryListProvider(List<String> historyList, Context context) {
        this.historyList = historyList;
        this.context = context;
    }

    @Override
    public int getCount() {
        return historyList.size();
    }

    @Override
    public Object getItem(int i) {
        return historyList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public Component getComponent(int i, Component component, ComponentContainer componentContainer) {
        DirectionalLayout dl=(DirectionalLayout) LayoutScatter.getInstance(context).parse(ResourceTable.Layout_history_lst_item, null,false);
        Text title = dl.findComponentById(ResourceTable.Id_history_list_title);
        Text content = dl.findComponentById(ResourceTable.Id_history_list_content);
        String itemData = historyList.get(i);
        String[] parts = itemData.split("~");
        title.setText(parts[0]);
        content.setText(parts[1]);
        return dl;
    }
}