package com.zqiang.klotskigame.controller;

import java.util.HashMap;
import java.util.Map;

public class GlobalManager {
    private static GlobalManager instance;
    private final Map<String, Boolean> globalVariables = new HashMap<>();  //保存全局变量

    private GlobalManager() {
    }

    /**
     * 初始化全局变量，只初始化一次
     * @return instance: 全局部变量实例
     */
    public static GlobalManager getInstance() {
        if (instance == null) {
            instance = new GlobalManager();
            instance.setGlobalVariable("history",true);
            instance.setGlobalVariable("timer",true);
            instance.setGlobalVariable("step",true);
            instance.setGlobalVariable("animation",false);
        }
        return instance;
    }

    /**
     * 设置全局变量
     * @param key
     * @param value
     */
    public void setGlobalVariable(String key, Boolean value) {
        globalVariables.put(key, value);
    }

    /**
     * 获取变量
     * @param key
     * @return
     */
    public Boolean getGlobalVariable(String key) {
        return globalVariables.get(key);
    }
}
