package com.zqiang.klotskigame.slice;

import com.zqiang.klotskigame.ResourceTable;
import com.zqiang.klotskigame.controller.HistoryListProvider;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.agp.components.Button;
import ohos.agp.components.ListContainer;
import ohos.agp.utils.LayoutAlignment;
import ohos.agp.window.dialog.ToastDialog;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class HistorySlice extends AbilitySlice {

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_ability_history);

        //获取历史记录
        ListContainer lcHistoryList = findComponentById(ResourceTable.Id_listContainer_history);
        List<String> historyList = getHistoryList();
        HistoryListProvider provider = new HistoryListProvider(historyList,this);
        lcHistoryList.setItemProvider(provider);
        //清空历史记录
        Button clearBtn=  findComponentById(ResourceTable.Id_history_clear);
        clearBtn.setClickedListener(component -> {
            clearHistory();
        });
        //返回主页
        Button returnBtn = findComponentById(ResourceTable.Id_histroy_return);
        returnBtn.setClickedListener(component -> {
            terminate();
        });
    }

    public List<String>getHistoryList(){
        List<String>data = new ArrayList<>();
        try{
            //读取文件
            File file = new File(getFilesDir(),"history.txt");
            if(file.exists()){
                BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
                String line;
                while ((line=bufferedReader.readLine())!=null){
                    data.add(line);
                }
                bufferedReader.close();
            }
            else {
                data.add("暂无历史记录~空");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }

    public void clearHistory(){
        try{
            File file = new File(getFilesDir(),"history.txt");
            if(file.exists()){
                if(file.delete()){
                    new ToastDialog(getContext())
                            .setText("历史记录已清空!")
                            .setAlignment(LayoutAlignment.CENTER)
                            .show();
                    //重新更新显示信息
                    ListContainer lcHistoryList = findComponentById(ResourceTable.Id_listContainer_history);
                    List<String> historyList = getHistoryList();
                    HistoryListProvider provider = new HistoryListProvider(historyList,this);
                    lcHistoryList.setItemProvider(provider);
                }
            }
            else{
                new ToastDialog((getContext()))
                        .setText("暂无历史记录!")
                        .setAlignment(LayoutAlignment.CENTER)
                        .show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }
}
