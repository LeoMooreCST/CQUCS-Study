package com.zqiang.klotskigame.slice;

import com.zqiang.klotskigame.ResourceTable;
import com.zqiang.klotskigame.controller.ImageListProvider;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.ability.DataAbilityHelper;
import ohos.aafwk.ability.DataAbilityRemoteException;
import ohos.aafwk.content.Intent;
import ohos.aafwk.content.Operation;
import ohos.agp.components.*;
import ohos.data.rdb.ValuesBucket;
import ohos.media.image.ImageSource;
import ohos.media.image.PixelMap;
import ohos.media.photokit.metadata.AVStorage;
import ohos.utils.net.Uri;

import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class ModeStartAbilitySlice extends AbilitySlice {
    private Image selectedImage;    //玩家选中或从外部获取的图片
    private Integer selectedImageSrc;  //玩家选中或从外部获取的图片id
    private final int RequestCode = 1010;  //拍照时的响应码
    Uri imageUri1;     //拍照获取的图像地址

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_ability_modestart);

        //初始化图片
        selectedImage = findComponentById(ResourceTable.Id_selected_image);
        ListContainer lcImgList = findComponentById(ResourceTable.Id_image_container);
        List<Integer> imgList = getImageList();
        //从已有的图片中加载到listContainer中
        ImageListProvider provider = new ImageListProvider(imgList,this);
        provider.setListener(pos -> {
            selectedImage.setPixelMap(imgList.get(pos));
            selectedImageSrc = imgList.get(pos);
        });
        lcImgList.setItemProvider(provider);
        //返回按钮
        Button returnBtn = findComponentById(ResourceTable.Id_md_return_btn);
        returnBtn.setClickedListener(component -> {
            terminate();
        });
        //选择游戏模式
        Picker rowPicker = findComponentById(ResourceTable.Id_row_picker);
        Picker colPicker = findComponentById(ResourceTable.Id_col_picker);
        Button startGameBtn = findComponentById(ResourceTable.Id_md_start_btn);
        //开始游戏
        startGameBtn.setClickedListener(component -> {
            Intent intent1 = new Intent();
            intent1.setParam("md_row",rowPicker.getValue());
            intent1.setParam("md_col",colPicker.getValue());
            if(selectedImageSrc!=null){
                intent1.setParam("imgSrc",selectedImageSrc);
            }
            present(new StartGameAbilitySlice(),intent1);
        });
        Button albumBtn = findComponentById(ResourceTable.Id_md_album_btn);
        Button cameraBtn = findComponentById(ResourceTable.Id_md_camera_btn);
        requestPermissionsFromUser(new String[]{"ohos.permission.READ_USER_STORAGE","ohos.permission.CAMERA"}, RequestCode);
        //相册选择
        albumBtn.setClickedListener(component -> {
            selectFromAlbum();
        });
        //拍照选择
        cameraBtn.setClickedListener(component -> {
            selectFromCamera();
        });
    }

    public List<Integer>getImageList(){
        List<Integer>lst = new ArrayList<>();
        lst.add(ResourceTable.Media_picture2);
        lst.add(ResourceTable.Media_picture3);
        lst.add(ResourceTable.Media_picture4);
        lst.add(ResourceTable.Media_picture5);
        return lst;
    }

    /**
     * 从相册中选择图片
     */
    private void selectFromAlbum() {
        Intent intent = new Intent();
        // 创建用于选择图片的操作
        Operation opt = new Intent.OperationBuilder().withAction("android.intent.action.GET_CONTENT").build();
        intent.setOperation(opt);
        intent.addFlags(Intent.FLAG_NOT_OHOS_COMPONENT);
        // 指定选择的文件类型为图像
        intent.setType("image/*");
        // 启动并等待相应结果
        startAbilityForResult(intent, RequestCode);
    }

    /**
     * 拍照选择
     */
    private void selectFromCamera() {
        ValuesBucket valuesBucket = new ValuesBucket();
        valuesBucket.putString("relative_path", "DCIM/Camera/");    // 存储路径
        valuesBucket.putString(AVStorage.Images.Media.MIME_TYPE, "image/JPEG"); // 图像类型
        DataAbilityHelper helper = DataAbilityHelper.creator(getContext());
        try {
            // 向外部数据能力插入图像，并获取图像的ID
            int id = helper.insert(AVStorage.Images.Media.EXTERNAL_DATA_ABILITY_URI, valuesBucket);
            // 构建图像的Uri
            imageUri1 = Uri.appendEncodedPathToUri(AVStorage.Images.Media.EXTERNAL_DATA_ABILITY_URI, String.valueOf(id));
            // 创建用于拍照的操作
            Intent intent = new Intent();
            Operation operation = new Intent.OperationBuilder()
                    .withAction("android.media.action.IMAGE_CAPTURE")
                    .build();
            intent.setOperation(operation);
            intent.setParam(AVStorage.Images.Media.OUTPUT, imageUri1); // 指定拍照后保存的图像位置
            startAbilityForResult(intent, 1);
        } catch (DataAbilityRemoteException e) {
            e.printStackTrace();
        }
    }

    protected void onAbilityResult(int requestCode, int resultCode, Intent resultData){
        //从相册中选择
        if (requestCode == RequestCode) {
            String imgUrl = null;
            try {
                imgUrl = resultData.getUriString(); // 从结果数据中获取图像的URL
            } catch (Exception e) {
                e.printStackTrace();
            }
            DataAbilityHelper helper = DataAbilityHelper.creator(getContext());
            ImageSource ims = null;
            String imgId = null;
            // 解析图像ID，处理URL中的特殊字符
            if (imgUrl.lastIndexOf("%3A") != -1) {
                imgId = imgUrl.substring(imgUrl.lastIndexOf("%3A") + 1);
            } else {
                imgId = imgUrl.substring(imgUrl.lastIndexOf("/") + 1);
            }
            // 构建正确的Uri，用于访问图像数据
            Uri uri = Uri.appendEncodedPathToUri(AVStorage.Images.Media.EXTERNAL_DATA_ABILITY_URI, imgId);
            try {
                // 打开文件并获取图像
                FileDescriptor fd = helper.openFile(uri, "r");
                ims = ImageSource.create(fd, null);
                PixelMap px = ims.createPixelmap(null);
                if (px != null) {
                    selectedImage.setScaleMode(Image.ScaleMode.STRETCH);
                    selectedImage.setPixelMap(px);
                    selectedImageSrc = null;
                }

            } catch (DataAbilityRemoteException | FileNotFoundException e) {
                e.printStackTrace();
            } finally {
                if (ims != null) {
                    ims.release();
                }
            }
        }
        //拍照选择
        else if(requestCode==1){
            DataAbilityHelper helper = DataAbilityHelper.creator(getContext());
            Uri uri = imageUri1;
            try{
                FileDescriptor fileDescriptor = helper.openFile(uri,"r");
                ImageSource ims = ImageSource.create(fileDescriptor,null);
                PixelMap px = ims.createPixelmap(null);
                if(px != null){
                    selectedImage.setScaleMode(Image.ScaleMode.STRETCH);
                    selectedImage.setPixelMap(px);
                    selectedImageSrc = null;
                }
            } catch (DataAbilityRemoteException | FileNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }
    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }
}
