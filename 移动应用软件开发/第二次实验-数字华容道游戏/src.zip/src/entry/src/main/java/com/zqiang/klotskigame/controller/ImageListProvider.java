package com.zqiang.klotskigame.controller;

import com.zqiang.klotskigame.ResourceTable;
import ohos.agp.components.*;
import ohos.app.Context;

import java.util.List;

public class ImageListProvider extends BaseItemProvider {
    List<Integer> imgList;
    Context context;
    ClickedListener listener;

    public ImageListProvider(List<Integer> imgList, Context context) {
        this.imgList = imgList;
        this.context = context;
    }



    public void setListener(ClickedListener listener){
        this.listener = listener;
    }
    public interface ClickedListener{
        void click(int pos);
    }
    @Override
    public int getCount() {
        return imgList.size();
    }

    @Override
    public Object getItem(int i) {
        return imgList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public Component getComponent(int i, Component component, ComponentContainer componentContainer) {
        DirectionalLayout dl=(DirectionalLayout) LayoutScatter.getInstance(context).parse(ResourceTable.Layout_img_lst_item, null,false);
        Image img= dl.findComponentById(ResourceTable.Id_img_list_item);
        img.setImageAndDecodeBounds(imgList.get(i));
        img.setClickedListener(component1 -> listener.click(i));
        return dl;
    }
}