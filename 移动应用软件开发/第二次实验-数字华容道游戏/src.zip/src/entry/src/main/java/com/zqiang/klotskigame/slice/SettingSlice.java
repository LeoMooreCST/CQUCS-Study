package com.zqiang.klotskigame.slice;

import com.zqiang.klotskigame.ResourceTable;
import com.zqiang.klotskigame.controller.GlobalManager;
import com.zqiang.klotskigame.controller.HistoryListProvider;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.agp.components.AbsButton;
import ohos.agp.components.Button;
import ohos.agp.components.ListContainer;
import ohos.agp.components.Switch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SettingSlice extends AbilitySlice {

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_ability_settings);
        //设置全局变量，只会产生一个实例，仅初始化一次
        GlobalManager globalManager = GlobalManager.getInstance();
        Switch btnSwiHistory = findComponentById(ResourceTable.Id_btn_switch_history);
        Switch btnSwiTime = findComponentById(ResourceTable.Id_btn_switch_time);
        Switch btnSwiStep = findComponentById(ResourceTable.Id_btn_switch_step);
        Switch btnSwiAni = findComponentById(ResourceTable.Id_btn_switch_animation);
        //是否打开历史记录
        btnSwiHistory.setCheckedStateChangedListener((absButton, b) -> {
            globalManager.setGlobalVariable("history", b);
        });
        //是否打开计时模式
        btnSwiTime.setCheckedStateChangedListener((absButton, b) -> {
            globalManager.setGlobalVariable("timer", b);
        });
        //是否打开记录步数
        btnSwiStep.setCheckedStateChangedListener((absButton, b) -> {
            globalManager.setGlobalVariable("step", b);
        });
        //是否打开滑动效果
        btnSwiAni.setCheckedStateChangedListener((absButton, b) -> {
            globalManager.setGlobalVariable("animation", b);
        });
        Button returnBtn = findComponentById(ResourceTable.Id_setting_return);
        returnBtn.setClickedListener(component -> {
            terminate();
        });
    }
    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }
}
