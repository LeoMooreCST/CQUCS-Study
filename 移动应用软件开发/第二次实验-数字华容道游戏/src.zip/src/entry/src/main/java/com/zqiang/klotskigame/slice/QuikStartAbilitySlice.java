package com.zqiang.klotskigame.slice;

import com.zqiang.klotskigame.ResourceTable;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.agp.components.Button;
import ohos.agp.components.Component;

public class QuikStartAbilitySlice extends AbilitySlice {

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_ability_quikstart);

        Button returnBtn = findComponentById(ResourceTable.Id_qk_return_btn);
        returnBtn.setClickedListener(component -> {
            terminate();
        });
        //3×3
        Button threeToThree = findComponentById(ResourceTable.Id_qk_3p3_btn);
        threeToThree.setClickedListener(component -> {
            Intent intent1 = new Intent();
            intent1.setParam("rc_type",3);
            present(new StartGameAbilitySlice(),intent1);
        });
        //6×6
        Button sixToSix = findComponentById(ResourceTable.Id_qk_6p6_btn);
        sixToSix.setClickedListener(component -> {
            Intent intent2 = new Intent();
            intent2.setParam("rc_type",6);
            present(new StartGameAbilitySlice(),intent2);
        });
        //9×9
        Button nineToNine = findComponentById(ResourceTable.Id_qk_9p9_btn);
        nineToNine.setClickedListener(component -> {
            Intent intent3 = new Intent();
            intent3.setParam("rc_type",9);
            present(new StartGameAbilitySlice(),intent3);
        });
    }

    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }
}
