package com.zqiang.klotskigame.slice;

import com.zqiang.klotskigame.ResourceTable;
import com.zqiang.klotskigame.controller.GlobalManager;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.agp.animation.Animator;
import ohos.agp.animation.AnimatorGroup;
import ohos.agp.animation.AnimatorProperty;
import ohos.agp.colors.RgbColor;
import ohos.agp.components.*;
import ohos.agp.components.element.PixelMapElement;
import ohos.agp.components.element.ShapeElement;
import ohos.agp.render.Canvas;
import ohos.agp.render.Paint;
import ohos.agp.render.Texture;
import ohos.agp.utils.Color;
import ohos.agp.utils.LayoutAlignment;
import ohos.agp.window.dialog.CommonDialog;
import ohos.global.resource.NotExistException;
import ohos.global.resource.Resource;
import ohos.media.image.ImagePacker;
import ohos.media.image.PixelMap;
import ohos.media.image.common.ImageInfo;
import ohos.media.image.common.Rect;
import ohos.media.image.common.Size;
import ohos.media.image.PixelMap;
import ohos.media.image.ImageSource;
import ohos.media.photokit.metadata.AVStorage;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Vector;

public class StartGameAbilitySlice extends AbilitySlice implements Component.ClickedListener{
    int row,col;  //游戏的总行数和列数
    Image picSrc;  //当前拼图的图像
    int splitWidth,splitHeight;  //分割图片的宽和高
    int blockWidth,blockHeight;  //每一拼图块所占宽和高
    PixelMap[][] pixelMaps;  //存储含数字拼图块的数组
    Image[][] pic;   //显示拼图块Image数组
    Integer[][] pos; //存储每个拼图块当前位置信息
    Image emptyImg;      //空白拼图块图像
    int nowi,nowj;      //当前拼图块的行列索引
    int emptyi,emptyj;     //空白拼图块的行列索引
    int steps = 0;      //移动步数
    TickTimer timer;   //计时器
    long startTime = 0, passTime = 0, flag = 0;   //时间计数
    Text sp;         //步数文本信息
    Boolean isHistory = true, isTimer = true, isStep = true, isAnimation = true;
    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        initPicSrc();  //初始化拼图的图片
        if(intent.hasParameter("rc_type")){ //如果是快速游戏界面
            row = col = intent.getIntParam("rc_type",2);
            picSrc.setPixelMap(ResourceTable.Media_picture1);
        }else{   //模式选择进入游戏
            row = intent.getIntParam("md_row",2);
            col = intent.getIntParam("md_col",2);
            if (intent.hasParameter("imgSrc")) {
                picSrc.setPixelMap(intent.getIntParam("imgSrc",0));
            } else{
                picSrc.setPixelMap(((Image) findComponentById(ResourceTable.Id_selected_image)).getPixelMap());
            }
        }
        getSettings();                          //获取游戏的设置信息
        initSplitParam();                       //初始化图片分割参数

        DirectionalLayout DL = buildBodyDL();   //动态创建整体布局
        DirectionalLayout topDL = buildDL(1); //容纳图片+游戏信息
        topDL.setMarginLeft(100); topDL.setMarginTop(100);
        DirectionalLayout topTextDL = buildTopTextDL();  //构建游戏信息布局
        topDL.addComponent(picSrc);
        topDL.addComponent(topTextDL);
        DirectionalLayout storePicDL = buildStorePicDL();  //构建存放拼图块的布局
        DL.addComponent(topDL);
        DL.addComponent(storePicDL);

        DirectionalLayout bottomDL = new DirectionalLayout(this);
        bottomDL.setMarginLeft(100);
        bottomDL.setMarginTop(100);
        bottomDL.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        bottomDL.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        bottomDL.setOrientation(Component.HORIZONTAL);
        bottomDL.setAlignment(LayoutAlignment.HORIZONTAL_CENTER);

        Button exit = buildButton("退出");
        exit.setClickedListener(component -> {
            CommonDialog cd = new CommonDialog(getContext());
            cd.setAlignment(LayoutAlignment.CENTER);
            cd.setTitleText("返回");
            cd.setContentText("确定退出游戏?");
            cd.setAlignment(LayoutAlignment.HORIZONTAL_CENTER);
            cd.setSize(550,450);
            cd.setButton(0, "是", (iDialog, i) -> {
                cd.destroy();
                terminate();
            });
            cd.setButton(1, "否", (iDialog, i) -> cd.destroy());
            cd.show();
        });
        Button reset = buildButton("重置");
        reset.setClickedListener(component -> {
            startTime = System.currentTimeMillis();
            timer.setBaseTime(startTime-passTime);
            timer.stop();
            flag = 0; steps=0;
            sp.setText("步数："+steps);
            random_shuffle();
        });
        bottomDL.addComponent(exit);
        bottomDL.addComponent(reset);
        DL.addComponent(bottomDL);

        super.setUIContent(DL);
    }

    /**
     * 获取游戏的设置信息
     */
    public void getSettings(){
        GlobalManager globalManager = GlobalManager.getInstance();
        isHistory = globalManager.getGlobalVariable("history");
        isTimer = globalManager.getGlobalVariable("timer");
        isStep = globalManager.getGlobalVariable("step");
        isAnimation = globalManager.getGlobalVariable("animation");
    }

    /**
     * 初始化拼图显示信息
     */
    public void initPicSrc(){
        picSrc = new Image(this);
        picSrc.setScaleMode(Image.ScaleMode.STRETCH);
        picSrc.setHeight(AttrHelper.vp2px(150,this));
        picSrc.setWidth(AttrHelper.vp2px(150,this));
        picSrc.setCornerRadius(20);
        picSrc.setPixelMap(ResourceTable.Id_selected_image);
    }

    /**
     * 初始化图片分割参数
     */
    public void initSplitParam(){
        pic = new Image[row+1][col+1];
        pixelMaps = new PixelMap[row+1][col+1];
        pos = new Integer[row+1][col+1];
        for(int i=0;i<=row;i++){
            for(int j=0;j<=col;j++)
                pos[i][j] = -1;
        }
        splitWidth = 200 /(row);splitHeight = 200 /(col);
    }

    /**
     *
     * @return 游戏界面整体布局
     */
    public DirectionalLayout buildBodyDL(){
        DirectionalLayout DL = new DirectionalLayout(this);
        DL.setOrientation(Component.VERTICAL);
        DL.setWidth(ComponentContainer.LayoutConfig.MATCH_PARENT);
        DL.setHeight(ComponentContainer.LayoutConfig.MATCH_PARENT);
        DL.setAlignment(LayoutAlignment.TOP);
        try {
            //设置游戏背景
            Resource resource = getResourceManager().getResource(ResourceTable.Media_gameback);
            PixelMapElement pixelMapElement = new PixelMapElement(resource);
            DL.setBackground(pixelMapElement);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NotExistException e) {
            throw new RuntimeException(e);
        }
        return DL;
    }

    public DirectionalLayout buildTopTextDL(){
        DirectionalLayout topTextDL = buildDL(0);  //显示游戏信息
        topTextDL.setAlignment(LayoutAlignment.LEFT);
        topTextDL.setMarginLeft(40);
        topTextDL.setPadding(20,20,20,20);
        setButtonBack(topTextDL,249,217,161);
        int infoSize = 70;
        //显示时间信息
        DirectionalLayout timeDL = buildDL(1);
        Text txt = new Text(this);
        txt.setText("耗时: ");
        txt.setTextSize(infoSize);
        timer = new TickTimer(this);
        timer.setCountDown(false);
        timer.setTextSize(infoSize);
        timeDL.addComponent(txt);
        timeDL.addComponent(timer);
        //显示难度信息
        Text diff = new Text(this);
        diff.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        diff.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        diff.setText("难度: "+row+"×"+col);
        diff.setTextSize(infoSize);
        //显示步数信息
        sp = new Text(this);
        sp.setTextSize(infoSize);
        sp.setText("步数: "+steps);
        topTextDL.addComponent(timeDL);
        topTextDL.addComponent(diff);
        topTextDL.addComponent(sp);
        return topTextDL;
    }

    /**
     *
     * @return 存放拼图块的DL
     */
    public DirectionalLayout buildStorePicDL(){
        for(int i=0;i<=row;i++){
            for(int j=0;j<=col;j++){   //划分拼图块，记录每一个拼图块的位置
                pic[i][j] = new Image(this);
                pic[i][j].setWidth(AttrHelper.vp2px(splitHeight,this));
                pic[i][j].setHeight(AttrHelper.vp2px(splitWidth,this));
                pic[i][j].setScaleMode(Image.ScaleMode.STRETCH);
                if(j!=0) pic[i][j].setMarginLeft(15);
                pic[i][j].setMarginTop(15);
                pic[i][j].setPixelMap(ResourceTable.Media_icon);
                if(i==row-1) pic[i][j].setMarginBottom(20);
                pic[i][j].setClickedListener(this);
            }
        }
        pic[row-1][col].setMarginRight(30);
        DirectionalLayout storePicDL = buildDL(0);   //构建存放拼图的布局
        storePicDL.setMarginTop(100);
        storePicDL.setAlignment(LayoutAlignment.TOP);
        setButtonBack(storePicDL,249,217,161);
        PixelMap px = picSrc.getPixelMap();
        cut_pic(px);    //划分拼图
        for(int i=0;i<row;i++){
            DirectionalLayout tmpd = new DirectionalLayout(this);  //每一行的拼图块
            tmpd.setMarginLeft(100);
            tmpd.setOrientation(Component.HORIZONTAL);
            tmpd.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
            tmpd.setHeight((ComponentContainer.LayoutConfig.MATCH_CONTENT));
            tmpd.setAlignment(LayoutAlignment.CENTER);
            for(int j=0;j<col;j++){
                tmpd.addComponent(pic[i][j]);
            }
            if(i==row-1) tmpd.addComponent(pic[i][col]);
            storePicDL.addComponent(tmpd);
        }
        return storePicDL;
    }

    /**
     *
     * @param name
     * @return formatted button
     */
    public Button buildButton(String name){
        Button Btn = new Button(this);
        Btn.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        Btn.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        Btn.setText(name);
        Btn.setTextColor(Color.WHITE);
        Btn.setTextSize(AttrHelper.fp2px(20,this));
        int cst = AttrHelper.vp2px(15,this);
        Btn.setPadding(cst,cst,cst,cst);
        Btn.setMarginLeft(150);
        setButtonBack(Btn,255,161,0);
        return Btn;
    }

    /**
     * 设置组件背景颜色
     * @param component: 组件
     * @param r
     * @param g
     * @param b
     */
    public void setButtonBack(Component component,int r,int g, int b){
        ShapeElement element = new ShapeElement();
        element.setShape(ShapeElement.RECTANGLE);
        element.setCornerRadius(30);
        element.setRgbColor(new RgbColor(r,g,b));
        element.setStroke(10,new RgbColor(255,161,0));
        component.setBackground(element);
    }

    /**
     *
     * @return 构建线性布局: 0为垂直方向，1为水平方向
     */
    public DirectionalLayout buildDL(int type){
        DirectionalLayout dl = new DirectionalLayout(this);
        if(type==0){
            dl.setOrientation(Component.VERTICAL);
        }else {
            dl.setOrientation(Component.HORIZONTAL);
        }
        dl.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl.setAlignment(LayoutAlignment.CENTER);
        return dl;
    }

    /**
     * 分割图片
     * @param pixelMap
     */
    public void cut_pic(PixelMap pixelMap){
        ImageInfo info = pixelMap.getImageInfo();
        //make initialization
        PixelMap.InitializationOptions opt = new PixelMap.InitializationOptions();
        int w = Math.min(info.size.height,info.size.width);
        opt.size = new Size();
        opt.size.width = opt.size.height = w;
        opt.pixelFormat = info.pixelFormat;
        opt.editable = true;
        //get cutted size
        Rect rect = new Rect();
        rect.minX = 0; rect.minY = 0; rect.width = blockHeight; rect.height =  blockWidth;
        PixelMap pixelMap1 = PixelMap.create(pixelMap,rect,opt);
        picSrc.setPixelMap(pixelMap1);
        info = pixelMap1.getImageInfo();
        blockWidth = info.size.height /row;
        blockHeight = info.size.width /col;
        int sz = Math.max( blockWidth,blockHeight);
        //分割图片
        int t = 0;
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                Rect r1 = new Rect();
                r1.height =  blockWidth;
                r1.width = blockHeight;
                r1.minX = j*blockHeight; r1.minY = i* blockWidth;
                PixelMap tmp = PixelMap.create(pixelMap1,r1,opt);
                Canvas canvas = new Canvas(new Texture(tmp));
                Paint paint = new Paint();
                paint.setTextSize(sz+150);
                paint.setColor(Color.RED);
                canvas.drawText(paint,""+(++t),blockHeight, blockWidth*(col-1));
                pixelMaps[i][j] = tmp;
            }
        }
        random_shuffle();
    }

    /**
     * 打乱生成随机数
     */
    public void random_shuffle(){
        //打乱
        Vector<Integer> lst = new Vector<>();
        for (int i = 0; i < row * col - 1; ++i) lst.add(i);
        // 生成逆序数为偶数的随机排列
        do {
            Collections.shuffle(lst);
        } while (getInversions(lst) % 2 != 0);
        // 确保最后一个数为 row * col - 1
        lst.add(row*col - 1);
        for(int i=0;i<=row*col-1;i++){
            pic[i/col][i%col+(i==row*col-1?1:0)].setPixelMap(pixelMaps[lst.get(i)/col][lst.get(i)%col]);
            pos[i/col][i%col+(i==row*col-1?1:0)] = lst.get(i);
        }
        emptyi = row-1; emptyj = col-1; emptyImg = pic[emptyi][emptyj];
        pic[emptyi][emptyj].setPixelMap(ResourceTable.Media_icon);
    }

    /**
     *
     * @param lst: 生成的随机数序列
     * @return inversions: 该序列的逆序数
     */
    private static int getInversions(Vector<Integer> lst) {
        int inversions = 0;
        for (int i = 0; i < lst.size(); i++) {
            for (int j = i + 1; j < lst.size(); j++) {
                if (lst.get(i) > lst.get(j)) {
                    inversions++;
                }
            }
        }
        return inversions;
    }

    /**
     * 点击图片
     * @param component
     */
    @Override
    public void onClick(Component component) {
        if(flag==0){
            startTime = System.currentTimeMillis();
            timer.setBaseTime(startTime-passTime);
            if(isTimer) timer.start();   //是否启动计时模式
            flag = 1;
        }
        find(component);   //找到当前点击的图片信息
        if(Math.abs(nowi - emptyi) + Math.abs(nowj - emptyj) == 1){
            if(isStep){   //是否启用记录步数
                ++steps;
                sp.setText("步数："+steps);
            }
            //交换点击的图片和空白块
            Image img1 = (Image) component;
            Image img2 = emptyImg;
            PixelMap p1 = img1.getPixelMap();
            PixelMap p2 = img2.getPixelMap();
            {
                Integer tmp = pos[nowi][nowj];
                pos[nowi][nowj] = pos[emptyi][emptyj];
                pos[emptyi][emptyj] = tmp;
            }
            //判断是否完成拼图
            if(isFinished()){
                double t = (System.currentTimeMillis()-startTime)/1000.0;
                String s = t + "";
                timer.stop();
                //创建成功提示窗口
                CommonDialog cd = new CommonDialog(getContext());
                DirectionalLayout dl = buildDL(0);
                dl.setAlignment(LayoutAlignment.CENTER);
                //是保存到历史记录
                if(isHistory){
                    String currRecord = "";
                    Date currentDate = new Date();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String formattedDate = sdf.format(currentDate);
                    int mm = (int) (t/60);
                    double ss = t - mm*60;
                    if(!isTimer){
                        mm = 0;
                        ss = 0;
                    }
                    currRecord =currRecord + formattedDate + "  难度: "+row+"×"+col+"~" +
                            "总移动步数: " + steps + "步" +
                            "用时: " + mm + "分 " + ss + "秒";
                    storageInHistory(currRecord);  //存储到历史记录
                }
                //设置成功拼图标题和文字信息
                Text title = new Text(this);
                title.setText("拼图完成!"); title.setTextSize(50);
                Text content = new Text(this);
                if(!isTimer) s = "null";
                content.setText("恭喜你完成了拼图!\n用时为:"+s+"\n步数为: "+steps);
                content.setTextSize(50);
                content.setMultipleLine(true);
                content.setMaxTextLines(4);
                //点击确定按钮刷新当前页面
                Button btn = new Button(this);
                btn.setText("确定");
                btn.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
                btn.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
                btn.setTextSize(50);
                btn.setClickedListener(component1 -> {
                    cd.destroy();
                    startTime = System.currentTimeMillis();
                    timer.setBaseTime(startTime-passTime);
                    timer.stop();
                    flag = 0; steps=0;
                    sp.setText("步数："+steps);
                    random_shuffle();
                });
                cd.setSize(450,450);
                dl.addComponent(title);
                dl.addComponent(content);
                dl.addComponent(btn);
                cd.setContentCustomComponent(dl);
                cd.show();
            }
            if(isAnimation) move(img1,img2);
            else {
                img1.setPixelMap(p2);
                img2.setPixelMap(p1);
            }
            emptyImg = img1; emptyi = nowi; emptyj = nowj;
        }
    }

    //寻找当前点击的拼图块
    public void find(Component component){
        for(int i=0;i<=row;i++){
            for(int j=0;j<=col;j++){
                if(component==pic[i][j]){
                    nowi = i;
                    nowj = j;
                    return;
                }
            }
        }
    }

    /**
     *
     * @return 是否完成
     */
    public boolean isFinished(){
        for(int i=0;i<row;++i){
            for(int j=0;j<col;++j){
                if(pos[i][j]!=(i)*col+j) return false;
            }
        }
        return true;
    }

    /**
     * 写入历史记录
     * @param data :胜利信息
     */
    public void storageInHistory(String data){
        try{
            String newData = String.join("\n",data);
            File file = new File(getFilesDir(),"history.txt");
            FileWriter fileWriter = new FileWriter(file,true);
            fileWriter.write(newData);
            fileWriter.append("\n");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 移动动画
     */
    float s_x,s_y,f_x,f_y;
    public void move(Image c1,Image c2){
        AnimatorProperty p1 = c1.createAnimatorProperty();
        AnimatorProperty p2 = c2.createAnimatorProperty();
        AnimatorGroup ag = new AnimatorGroup();
        ag.setStateChangedListener(new Animator.StateChangedListener() {
            @Override
            public void onStart(Animator animator) {}
            @Override
            public void onStop(Animator animator) {}
            @Override
            public void onCancel(Animator animator) {}
            @Override
            public void onEnd(Animator animator) {
                c1.setContentPositionX(s_x);
                c1.setContentPositionY(s_y);
                c2.setContentPositionX(f_x);
                c2.setContentPositionY(f_y);
                PixelMap pi1 = c1.getPixelMap();
                PixelMap pi2 = c2.getPixelMap();
                c2.setPixelMap(pi1);
                c1.setPixelMap(pi2);
            }
            @Override
            public void onPause(Animator animator) {}
            @Override
            public void onResume(Animator animator) {}
        });
        ag.setDuration(500);
        s_x = c1.getContentPositionX();
        s_y = c1.getContentPositionY();
        f_x = c2.getContentPositionX();
        f_y = c2.getContentPositionY();
        if(s_x == f_x){
            if(nowi<emptyi){
                p1.moveFromY(f_y).moveToY(f_y+15+splitWidth);
                p2.moveFromY(f_y).moveToY(f_y-15-splitWidth);
            }
            else {
                p2.moveFromY(f_y).moveToY(f_y+15+splitWidth);
                p1.moveFromY(f_y).moveToY(f_y-15-splitWidth);
            }
        } else {
            p1.moveFromX(s_x).moveToX(f_x);
            p2.moveFromX(f_x).moveToX(s_x);
        }
        ag.runParallel(p1,p2);
        ag.start();
    }
    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }
}
