package com.zqiang.klotskigame;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
