#include "backend/rv_inst_impl.h"
#include<cassert>
using rv::rvOPCODE;
#define MASK01F 0xfffff01f
#define MASK41F 0xfffff41f
#define COMMA ","
#define endl "\n"
std::string rv::rv_inst::draw() const {
    switch (op)
    {   /*以下是普通的R型指令*/
        case rvOPCODE::ADD:     //add
        case rvOPCODE::SUB:     //sub
        case rvOPCODE::MUL:
        case rvOPCODE::DIV:
        case rvOPCODE::XOR:     //xor
        case rvOPCODE::OR:      //or
        case rvOPCODE::AND:     //and
        case rvOPCODE::SLL:     //sll
        case rvOPCODE::SRL:     //srl
        case rvOPCODE::SRA:     //sra
        case rvOPCODE::SLT:     //slt
        case rvOPCODE::SLTU:    //sltu
        case rvOPCODE::REM:
            //eg:   add   rd1,rs1,rs2
            return "\t" + toString(op) + "\t" + toString(rd) + COMMA+ toString(rs1) + COMMA + toString(rs2) + endl;
        
        /*以下是普通的I型指令*/
        case rvOPCODE::ADDI:    //addi
        case rvOPCODE::XORI:    //xori
        case rvOPCODE::ORI:     //ori
        case rvOPCODE::ANDI:    //andi
        case rvOPCODE::SLTI:    //slti
        case rvOPCODE::SLTIU:   //sltiu
            //eg:   addi    rd1,rs1,imm
            return "\t" + toString(op) + "\t" + toString(rd) + COMMA + toString(rs1) + COMMA + std::to_string(imm) + endl;
        
        /*
            SLLI, SRLI 算术运算指令, 
                由于imm[5:11] = 0x00并且只对imm[0:4]进行运算
                故可设置掩码0xfffff01f => 后面几位: 000000011111
            对于SRAI:
                imm[5:11] = 0x20 = 0100000 11111 = 41f
        */
        case rvOPCODE::SLLI:    //slli
        case rvOPCODE::SRLI:    //srli
            return "\t" + toString(op) + "\t" + toString(rd) + COMMA+ toString(rs1) + COMMA + std::to_string(imm & MASK01F) + endl;
        case rvOPCODE::SRAI:    //srai
            return "\t" + toString(op) + "\t" + toString(rd) + COMMA+ toString(rs1) + COMMA + std::to_string(imm & MASK41F) + endl;
        
        /**以下是条件跳转指令*/
        case rvOPCODE::BEQ:
        case rvOPCODE::BNE:
        case rvOPCODE::BLT:
        case rvOPCODE::BGE:
        case rvOPCODE::BLTU:
        case rvOPCODE::BGEU:
            if(label.length()) {
                return "\t" + toString(op) + "\t" + toString(rs1) + COMMA + toString(rs2) + COMMA + label + endl;
            }
            else {
                return "\t" + toString(op) + "\t" + toString(rs1) + COMMA + toString(rs2) + COMMA + std::to_string(imm) + endl;
            }
        //jal rd, imm(rd = PC + 4, PC += imm)
        case rvOPCODE::JAL:
            if(label.length()) {
                return "\t" + toString(op) + "\t" + toString(rd) + COMMA+ label + endl;
            }
            else {
                return "\t" + toString(op) + "\t" + toString(rd) + COMMA+ std::to_string(imm) + endl;
            }
        //jalr rd, rs1, imm(rd = PC + 4, PC = rs1 + imm)
        case rvOPCODE::JALR:
            if(label.length()) {
                return "\t" + toString(op) + "\t" + toString(rd) + COMMA+ toString(rs1) + COMMA + label + endl;
            }
            else {
               return "\t" + toString(op) + "\t" + toString(rd) + COMMA+ toString(rs1) + COMMA + std::to_string(imm) + endl; 
            }
        
        /*以下是数组操作指令*/
        //lw rd, offset(rs1)
        case rvOPCODE::LW:
            return "\t" + toString(op) + "\t" + toString(rd) + COMMA+ std::to_string(imm) + "(" + toString(rs1) + ")" + endl;
        //sw rs2, offset(rs1)
        case rvOPCODE::SW:
            return "\t" + toString(op) + "\t" + toString(rs2) + COMMA + std::to_string(imm) + "(" + toString(rs1) + ")" + endl;
        
        /*以下是伪指令*/
        //la => rd, symbol
        case rvOPCODE::LA:
            return "\t" + toString(op) + "\t" + toString(rd) + COMMA+ label + endl;
        //li => rd, imm 取立即数
        case rvOPCODE::LI:
            return "\t" + toString(op) + "\t" + toString(rd) + COMMA+ std::to_string(imm) + endl;
        //mov => rd, rs
        case rvOPCODE::MOV:
            return "\t" + toString(op) + "\t" + toString(rd) + COMMA+ toString(rs1) + endl;
        //j => offset/symbol
        case rvOPCODE::J:
            if(label.length()) return "\t" + toString(op) + "\t" + label + endl;
            else               return "\t" + toString(op) + "\t" + std::to_string(imm) + endl;
        //ret 
        case rvOPCODE::RET:
            return toString(op) + endl;
        //call
        case rvOPCODE::CALL:
            return "\t" + toString(op) + "\t" + label + endl;
        //jr ra
        case rvOPCODE::JR:
            return "\t" + toString(op) + "\t" + "ra" + endl;
        //nop
        case rvOPCODE::NOP:
            return "\tnop\t\n";
        default: assert(0 && "Unknow Opcode!");
    }
}