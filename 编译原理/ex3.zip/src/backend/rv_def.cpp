#include "backend/rv_def.h"
#include <cassert>
#include <iostream>
using rv::rvREG;
using rv::rvFREG;
using rv::rvOPCODE;
// #define ERROR(scope, error) \
//     std::string e1 = "[" + scope + "] " + error; \
//     assert(0 && e1);

//获取整数寄存器的string
std::string rv::toString(rvREG r) {
    switch (r)
    {
        case rvREG::X0: return "zero";
        case rvREG::X1: return "ra";
        case rvREG::X2: return "sp";
        case rvREG::X3: return "gp";
        case rvREG::X4: return "fp";  //s0
        //临时寄存器
        case rvREG::X5: return "t0";
        case rvREG::X6: return "t1";
        case rvREG::X7: return "t2";
        case rvREG::X28: return "t3";
        case rvREG::X29: return "t4";
        case rvREG::X30: return "t5";
        case rvREG::X31: return "t6";
        //函数参数/返回值 寄存器
        case rvREG::X10: return "a0";
        case rvREG::X11: return "a1";
        //函数参数寄存器
        case rvREG::X12: return "a2";
        case rvREG::X13: return "a3";
        case rvREG::X14: return "a4";
        case rvREG::X15: return "a5";
        case rvREG::X16: return "a6";
        case rvREG::X17: return "a7";
        //保存寄存器
        case rvREG::X8: return "s0";
        case rvREG::X9: return "s1";
        case rvREG::X18: return "s2";
        case rvREG::X19: return "s3";
        case rvREG::X20: return "s4";
        case rvREG::X21: return "s5";
        case rvREG::X22: return "s6";
        case rvREG::X23: return "s7";
        case rvREG::X24: return "s8";
        case rvREG::X25: return "s9";
        case rvREG::X26: return "s10";
        case rvREG::X27: return "s11";
        default: return "zero";
        //default: assert(0 && "[toString(rvREG r)]: Unexpected REG Type!");
    }
    return "zero";
}

//获取浮点数寄存器的string
std::string rv::toString(rvFREG r) {
    switch (r)
    {
        //浮点临时寄存器    ft0-ft7
        case rvFREG::F0: return "ft0";
        case rvFREG::F1: return "ft1";
        case rvFREG::F2: return "ft2";
        case rvFREG::F3: return "ft3";
        case rvFREG::F4: return "ft4";
        case rvFREG::F5: return "ft5";
        case rvFREG::F6: return "ft6";
        case rvFREG::F7: return "ft7";
        //ft8-ft11
        case rvFREG::F28: return "ft8";
        case rvFREG::F29: return "ft9";
        case rvFREG::F30: return "ft10";
        case rvFREG::F31: return "ft11";
        //浮点保存寄存器    fs0-fs12 [保留]
        case rvFREG::F8:  return "fs0";
        case rvFREG::F9:  return "fs1";
        case rvFREG::F18:  return "fs2";
        case rvFREG::F19:  return "fs3";
        case rvFREG::F20:  return "fs4";
        case rvFREG::F21:  return "fs5";
        case rvFREG::F22:  return "fs6";
        case rvFREG::F23:  return "fs7";
        case rvFREG::F24:  return "fs8";
        case rvFREG::F25:  return "fs9";
        case rvFREG::F26:  return "fs10";
        case rvFREG::F27:  return "fs11";
        //浮点参数/返回值   fa0-fa1
        case rvFREG::F10:  return "fa0";
        case rvFREG::F11:  return "fa1";
        //浮点参数
        case rvFREG::F12:  return "fa2";
        case rvFREG::F13:  return "fa3";
        case rvFREG::F14:  return "fa4";
        case rvFREG::F15:  return "fa5";
        case rvFREG::F16:  return "fa6";
        case rvFREG::F17:  return "fa7";
        default: assert(0 && "[toString(rvFREG r)]: Unexpected FREG Type!");
    }
    return "ft0";
}

//获取操作码的string
std::string rv::toString(rvOPCODE op) {
    switch (op)
    {
        //算术运算和逻辑运算指令R型
        case rvOPCODE::ADD:     return "add";
        case rvOPCODE::SUB:     return "sub";
        case rvOPCODE::MUL:     return "mul";
        case rvOPCODE::DIV:     return "div";
        case rvOPCODE::XOR:     return "xor";
        case rvOPCODE::AND:     return "and";
        case rvOPCODE::SLL:     return "sll";
        case rvOPCODE::SRL:     return "srl";
        case rvOPCODE::SRA:     return "sra";
        case rvOPCODE::SLT:     return "slt";
        case rvOPCODE::SLTU:     return "sltu";
        case rvOPCODE::REM:      return "rem";
        case rvOPCODE::OR:       return "or";
        //立即数
        case rvOPCODE::ADDI:     return "addi";
        case rvOPCODE::XORI:     return "xori";
        case rvOPCODE::ORI:     return "ori";
        case rvOPCODE::SLLI:     return "slli";
        case rvOPCODE::SRLI:     return "srli";
        case rvOPCODE::SRAI:     return "srai";
        case rvOPCODE::SLTI:     return "slti";
        case rvOPCODE::SLTIU:     return "sltiu";
        //load and store
        case rvOPCODE::LW:     return "lw";
        case rvOPCODE::SW:     return "sw";
        //条件跳转指令
        case rvOPCODE::BEQ:     return "beq";
        case rvOPCODE::BNE:     return "bne";
        case rvOPCODE::BLT:     return "blt";
        case rvOPCODE::BGE:     return "bge";
        case rvOPCODE::BLTU:     return "bltu";
        case rvOPCODE::BGEU:     return "bgeu";
        //无条件跳转指令
        case rvOPCODE::JAL:      return "jal";
        case rvOPCODE::JALR:     return "jalr";
        case rvOPCODE::JR:       return "jr";

        case rvOPCODE::LI:      return "li";
        case rvOPCODE::LA:      return "la";
        case rvOPCODE::MOV:     return "mv";
        case rvOPCODE::RET:     return "ret";
        case rvOPCODE::CALL:    return "call";
        case rvOPCODE::NOP:     return "nop";
        case rvOPCODE::J:       return "j";
        default:  assert(0 && "[toString(rvOPCODE OP)]: Unexpected OPCODE Type!");
    }
}
