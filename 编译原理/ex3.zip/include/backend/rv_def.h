#ifndef RV_DEF_H
#define RV_DEF_H

#include<string>

namespace rv {

// rv interger registers
enum class rvREG {
    /* Xn       its ABI name*/
    X0,         // zero         硬编码0
    X1,         // ra           返回指针
    X2,         // sp[保留]     栈指针
    X3,         // gp           全局指针
    X4,         // tp           线程指针
    X8,         // s0(/fp)[保留] 帧指针                 
    //临时寄存器
    X5,         // t0    
    X6,         // t1
    X7,         // t2
    X28,        // t3
    X29,        // t4
    X30,        // t5
    X31,        // t6
    //函数参数(含返回值)寄存器
    X10,        // a0            函数参数/返回值
    X11,        // a1            函数参数/返回值
    //函数参数寄存器
    X12,        // a2
    X13,        // a3
    X14,        // a4
    X15,        // a5
    X16,        // a6
    X17,        // a7
    //保存寄存器
    X9,         // s1[保留]
    X18,        // s2[保留]
    X19,        // s3[保留]
    X20,        // s4[保留]
    X21,        // s5[保留]
    X22,        // s6[保留]
    X23,        // s7[保留]
    X24,        // s8[保留]
    X25,        // s9[保留]
    X26,        // s10[保留]
    X27,        // s11[保留]

};
std::string toString(rvREG r);  // implement this in ur own way

enum class rvFREG {
    //浮点临时寄存器    ft0-ft7
    F0,
    F1,
    F2,
    F3,
    F4,
    F5,
    F6,
    F7,
    //ft8-ft11
    F28,
    F29,
    F30,
    F31,
    //浮点保存寄存器    fs0-fs11 [保留]
    F8,
    F9,
    F18,
    F19,
    F20,
    F21,
    F22,
    F23,
    F24,
    F25,
    F26,
    F27,
    //浮点参数/返回值   fa0-fa1
    F10,
    F11,
    //浮点参数          fa2-fa7
    F12,
    F13,
    F14,
    F15,
    F16,
    F17,    
};
std::string toString(rvFREG r);  // implement this in ur own way

// rv32i instructions
// add instruction u need here!
enum class rvOPCODE {
    // RV32I Base Integer Instructions
    ADD, SUB, XOR, OR, AND, SLL, SRL, SRA, SLT, SLTU,       // arithmetic & logic
    ADDI, XORI, ORI, ANDI, SLLI, SRLI, SRAI, SLTI, SLTIU,   // immediate
    LW, SW,                                                 // load & store
    BEQ, BNE, BLT, BGE, BLTU, BGEU,                         // conditional branch
    JAL, JALR,                                              // jump

    // RV32M Multiply Extension

    // RV32F / D Floating-Point Extensions

    // Pseudo Instructions
    LA, LI, MOV, J, JR, 
    //其他伪指令                                        //
    RET, CALL, NOP, 
    MUL, DIV,
    REM

};
std::string toString(rvOPCODE r);  // implement this in ur own way


} // namespace rv



#endif