#ifndef LEXICAL_FUNC_H
#define LEXICAL_FUNC_H

#include "front/lexical.h"

bool is_operator(char c);               //是否为操作数
bool ispossible_compound_op(char c);    //是否可能为双字母操作数
bool is_single_op(std::string c);       //是否为单字母操作数
bool is_compound_op(std::string c);     //是否为多字母操作数
bool is_number(char c);                 //是否为数字
bool is_compound_ident(char c);         //是否为复合标识符
bool is_null_char(char c);              //判断是否为空串
frontend::TokenType get_op_type(std::string s);     //获取操作数类型
frontend::TokenType get_keyword_type(std::string s);//获取关键字类型
std::string preproccess(std::ifstream &fin);
#endif

