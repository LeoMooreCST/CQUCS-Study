#include "front/lexical_func.h"
#include <cassert>
/**
 * @brief       判断是否为操作数
 * @param: c    输入的字符
 * @return      是否为操作数
*/
bool is_operator(char c)
{
    std::string s = "+-*/%<>,:=;()[]{}!&|";
    for(size_t i = 0; i < s.size(); i++){
        if(c == s[i]) return true;
    }
    return false;
}

/**
 * @brief       判断是否有可能为两个字符的运算符
 * @param c     输入的字符
 * @return      当c = <, >, =, !, &, |时返回true
*/
bool ispossible_compound_op(char c)
{
    std::string s = "<>=!&|";
    for(size_t i = 0; i < s.size(); i++){
        if(c == s[i]) return true;
    }
    return false;
}

/**
 * @brief       判断是否为单字母运算符
 * @param c     输入的字符串
 * @return      当 c = +, -,*,/,%,<,>,:=;()[]{}时返回true
*/
bool is_single_op(std::string c)
{
    std::string s = "+-*/%<>,:=;()[]{}";
    for(size_t i = 0; i < s.size(); i++){
        if(c == s.substr(0,1)) return true;
    }
    return false;
}

/**
 * @brief       判断是否为双字符运算符
 * @param  c    输入的字符串
 * @return      当c = "<=", ">=", "==", "!=", "&&", "||"时返回true
*/
bool is_compound_op(std::string c)
{
    return (c == "<=") || (c == ">=") || (c == "==") ||
           (c == "!=") || (c == "&&") || (c == "||");
}

/**
 * @brief   判断是否为数字
*/
bool is_number(char c)
{
    return (c >= '0' && c <= '9');
}

/**
 * @brief 判断是否为ident组合
*/
bool is_compound_ident(char c)
{
    return isalpha(c) || c == '_';
}

/**
 * @brief 判断是否为空串
*/
bool is_null_char(char c){
    return (c == ' '  || c == '\n' || 
            c == '\t' || c == '\r');
}

/**
 * @brief 获取操作数的类型
*/
frontend::TokenType get_op_type(std::string s)
{
    if(s.length() == 1){
        switch (s[0])
        {
        case '+':   return frontend::TokenType::PLUS;
        case '-':   return frontend::TokenType::MINU;
        case '*':   return frontend::TokenType::MULT;
        case '/':   return frontend::TokenType::DIV;
        case '%':   return frontend::TokenType::MOD;
        case '<':   return frontend::TokenType::LSS;
        case '>':   return frontend::TokenType::GTR;
        case ':':   return frontend::TokenType::COLON;
        case '=':   return frontend::TokenType::ASSIGN;
        case ';':   return frontend::TokenType::SEMICN;
        case ',':   return frontend::TokenType::COMMA;
        case '(':   return frontend::TokenType::LPARENT;
        case ')':   return frontend::TokenType::RPARENT;
        case '[':   return frontend::TokenType::LBRACK;
        case ']':   return frontend::TokenType::RBRACK;
        case '{':   return frontend::TokenType::LBRACE;
        case '}':   return frontend::TokenType::RBRACE;
        case '!':   return frontend::TokenType::NOT;
        default:    assert(0 && "invalid op type"); //assert(0 && "invalid op type");
        }
    }
    else if(s.length() == 2){
        if(s == "<=")       return frontend::TokenType::LEQ;
        else if(s == ">=")  return frontend::TokenType::GEQ;
        else if(s == "==")  return frontend::TokenType::EQL;
        else if(s == "!=")  return frontend::TokenType::NEQ;
        else if(s == "&&")  return frontend::TokenType::AND;
        else if(s == "||")  return frontend::TokenType::OR;
        else                assert(0 && "invalid op type");
    }
    return frontend::TokenType::PLUS;
}

/**
 * @brief 获取关键字类型
*/
frontend::TokenType get_keyword_type(std::string s){
    if(s == "const")        return frontend::TokenType::CONSTTK;
    else if(s == "void")    return frontend::TokenType::VOIDTK;
    else if(s == "int")     return frontend::TokenType::INTTK;
    else if(s == "float")   return frontend::TokenType::FLOATTK;
    else if(s == "if")      return frontend::TokenType::IFTK;
    else if(s == "else")    return frontend::TokenType::ELSETK;
    else if(s == "while")   return frontend::TokenType::WHILETK;
    else if(s == "continue")return frontend::TokenType::CONTINUETK;
    else if(s == "break")   return frontend::TokenType::BREAKTK;
    else if(s == "return")  return frontend::TokenType::RETURNTK;
    else                    return frontend::TokenType::IDENFR;    
}
/**
 * @brief 对测试文件串进行预处理, 去除注释部分
*/
std::string preproccess(std::ifstream &fin){
    std::string line;
    std::string newString = "";
    bool is_comment = false;
    while(std::getline(fin, line)){
        line += "\n";
        line.erase(0, line.find_first_not_of(" "));  //去除行首字符串
        for(size_t i = 0; i < line.size(); i++){
            //单行注释
            if(i < line.size()-1 && line[i] == '/' && line[i+1] == '/') break;
            if(i < line.size()-1 && line[i] == '/' && line[i+1] == '*') {
                is_comment = true;
                i += 2;
            }
            if(i < line.size()-1 && line[i] == '*' && line[i+1] == '/'){
                is_comment = false;
                i += 2;
            }
            if(!is_comment) newString += line[i];
        }
    }
    return newString;
}